package com.demo.extension.runtime;

import io.quarkus.runtime.annotations.ConfigPhase;
import io.quarkus.runtime.annotations.ConfigRoot;
import io.smallrye.config.ConfigMapping;
import io.smallrye.config.WithDefault;

import java.util.Optional;
import java.util.logging.Level;

@ConfigMapping(prefix = "quarkus.log.custom",namingStrategy = ConfigMapping.NamingStrategy.SNAKE_CASE)
@ConfigRoot(phase = ConfigPhase.RUN_TIME)
public interface ExtensionRuntimeConfig {



	/**
	 * The CW log level.
	 */
	@WithDefault("INFO")
	Level level();

	/**
	 *  type
	 */
	@WithDefault("java")
	String type();


	/**
	 * Log format
	 */
	@WithDefault("d{HH:mm:ss,SSS} %-5p [%c{1.}] %s%e%n")
	String format();

}
