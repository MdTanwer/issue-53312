package com.demo.extension.runtime;

import io.quarkus.arc.Arc;
import io.quarkus.runtime.RuntimeValue;
import io.quarkus.runtime.annotations.Recorder;
import io.quarkus.runtime.logging.DiscoveredLogComponents;

import java.util.*;
import java.util.logging.Handler;

@Recorder
public class CustomLogHandlerRecorder {


	static final         String                   PATTERN_DEFAULT      = "%d{HH:mm:ss,SSS} %-5p [%c{1.}] %s%e%n";
	private final        ExtensionRuntimeConfig   runtimeConfig;
//	private final        ExtensionBuildConfig     buildConfig;

	public CustomLogHandlerRecorder(ExtensionRuntimeConfig runtimeConfig) {
		this.runtimeConfig = runtimeConfig;
//		this.buildConfig = buildtimeConfig;
	}

	public RuntimeValue<Optional<Handler>> create(DiscoveredLogComponents components) {
		return new RuntimeValue<>(Optional.of(new CustomLogHandler()));
	}

}
