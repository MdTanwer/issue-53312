package com.demo.extension.runtime;

import org.jboss.logmanager.ExtHandler;
import org.jboss.logmanager.ExtLogRecord;

public class CustomLogHandler extends ExtHandler {

	@Override
	protected void doPublish(ExtLogRecord record) {
		super.doPublish(record);
	}
}
