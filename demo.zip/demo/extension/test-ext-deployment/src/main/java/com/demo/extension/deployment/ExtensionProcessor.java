package com.demo.extension.deployment;

import com.demo.extension.runtime.CustomLogHandlerRecorder;
import io.quarkus.deployment.IsLocalDevelopment;
import io.quarkus.deployment.annotations.BuildProducer;
import io.quarkus.deployment.annotations.BuildStep;
import io.quarkus.deployment.annotations.ExecutionTime;
import io.quarkus.deployment.annotations.Record;
import io.quarkus.deployment.builditem.CombinedIndexBuildItem;
import io.quarkus.deployment.builditem.FeatureBuildItem;
import io.quarkus.deployment.builditem.LogHandlerBuildItem;
import io.quarkus.deployment.util.JandexUtil;
import io.quarkus.devui.spi.page.CardPageBuildItem;
import io.quarkus.devui.spi.page.Page;
import io.quarkus.logging.LoggingFilter;
import io.quarkus.runtime.logging.DiscoveredLogComponents;
import org.jboss.jandex.AnnotationInstance;
import org.jboss.jandex.AnnotationTarget;
import org.jboss.jandex.ClassInfo;
import org.jboss.jandex.DotName;
import org.jboss.jandex.IndexView;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Filter;

class ExtensionProcessor {

	@BuildStep(onlyIf = IsLocalDevelopment.class)
	void createCheckedTemplatesCard(BuildProducer<CardPageBuildItem> producer) {

		CardPageBuildItem card = new CardPageBuildItem();
		// Logo files live under the extension's dev-ui/ resources dir and are served by the
		// Quarkus Dev UI webjar machinery. Using a local asset (vs. an external URL) is the
		// canonical pattern — see quarkus/extensions/smallrye-health for a reference.
//		card.setLogo("thymeleaf.png", "thymeleaf.png");

		// Bindings table: one row per @CheckedTemplate method.


		card.addPage(Page.webComponentPageBuilder()
				//				.title("Thymeleaf")
				.icon("font-awesome-solid:table-list")
				.componentLink("qwc-checked-templates.js")
				.staticLabel("Hello"));


		card.addLibraryVersion("org.eclipse.microprofile.health", "microprofile-health-api", "MicroProfile Health",
				"https://github.com/microprofile/microprofile-health");
		producer.produce(card);

		//		CardPageBuildItem cardPageBuildItem = new CardPageBuildItem();
		//		cardPageBuildItem.setLogo("clown.svg", "clown.svg");
		//
		//		cardPageBuildItem.addPage(Page.webComponentPageBuilder()
		//				.title("Quarkus Thymeleaf")
		//				.icon("font-awesome-solid:cubes")
		//				.componentLink("qwc-jokes-list.js"));
		//
		//		producer.produce(cardPageBuildItem);
	}

}
