package com.demo.app;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/hello")
public class ExampleResource {


//	@Inject
//	DemoLibImpl demoLib;
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String hello() {
		return "OK";
	}
}
